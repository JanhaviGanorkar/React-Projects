function Chai(){
    return(
        <h3>chai is ready</h3>
    )
}

export default Chai