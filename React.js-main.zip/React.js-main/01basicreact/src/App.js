
import Chai from "./Chai";

function App() {
  return (
    <>
    <Chai/>
    
    </>
  );
}

export default App;
